<?php
session_start();
$MerchantID  = '0f1c6166-0dde-11e8-8c14-005056a205be'; //Required
$Amount      = 100;//$_SESSION['sumAll']; //Amount will be based on Toman  - Required
$Description = 'توضیحات تراکنش تستی'; // Required
$Email       = 'noohpishehhossein@gmail.com'; // Optional
$Mobile      = $_SESSION['phone']; // Optional
$CallbackURL = 'verify.php'; // Required
//http://www.fooderz.ir/Zarinpal/

// URL also can be ir.zarinpal.com or de.zarinpal.com
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', array('encoding' => 'UTF-8'));

$result = $client->PaymentRequest(array(
    'MerchantID'  => $MerchantID,
    'Amount'      => $Amount,
    'Description' => $Description,
    'Email'       => $Email,
    'Mobile'      => $Mobile,
    'CallbackURL' => $CallbackURL,
));

//Redirect to URL You can do it also by creating a form
if ($result->Status == 100)
{
    header('Location: https://www.zarinpal.com/pg/StartPay/' . $result->Authority);
}
else
{
    echo 'ERR: ' . $result->Status;
}
